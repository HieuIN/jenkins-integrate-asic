# Spring MVC Example Using Java 11

This web application is an example of using latest Spring 5, Java 11, JUnit 5, and log4j2
libraries.



## Build and Deploy

### Local Deployment

mvn -e clean package

copy target/spring-mvc-java11.war to Tomcat's webapps folder

visit http://localhost:8080/spring-mvc-java11



